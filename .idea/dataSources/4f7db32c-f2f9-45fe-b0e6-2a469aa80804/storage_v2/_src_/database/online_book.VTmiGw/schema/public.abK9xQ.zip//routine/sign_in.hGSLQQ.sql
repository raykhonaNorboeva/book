create function sign_in(i_username character varying, i_password character varying) returns SETOF users
    language plpgsql
as
$$
begin
    return query select * from users
                 where i_password = password and
                     i_username = username and is_active = true;
end;
$$;

alter function sign_in(varchar, varchar) owner to postgres;

