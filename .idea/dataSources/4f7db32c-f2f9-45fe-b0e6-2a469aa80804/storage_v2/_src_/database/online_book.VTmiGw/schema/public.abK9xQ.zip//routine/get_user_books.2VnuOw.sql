create function get_user_books(i_owner_id uuid) returns SETOF books
    language plpgsql
as
$$
    begin
        return query select * from books where books.owner_id = i_owner_id and is_active = true;
    end;
    $$;

alter function get_user_books(uuid) owner to postgres;

