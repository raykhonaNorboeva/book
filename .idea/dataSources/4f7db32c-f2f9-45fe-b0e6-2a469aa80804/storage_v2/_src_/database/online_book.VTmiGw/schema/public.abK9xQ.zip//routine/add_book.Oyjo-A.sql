create function add_book(i_title character varying, i_description character varying, i_author character varying, i_picture_path character varying, i_book_path character varying, i_genre character varying, i_owner_id uuid) returns integer
    language plpgsql
as
$$
begin
    if exists(select *
              from books
              where title = i_title
                and description = i_description
                and author = i_author
                and genre = i_genre) then
        return -1;
    else
        insert into books(title,
                          description,
                          author,
                          picture_path,
                          book_path,
                          genre,
                          owner_id)
        values (i_title,
                i_description,
                i_author,
                i_picture_path,
                i_book_path,
                i_genre,
                i_owner_id);
        return 1;
    end if;
end;
$$;

alter function add_book(varchar, varchar, varchar, varchar, varchar, varchar, uuid) owner to postgres;

