create function get_all_books(page integer, lmt integer DEFAULT 3) returns SETOF books
    language plpgsql
as
$$
    begin
        return query select * from books limit lmt offset (page - 1) * lmt;
    end;
    $$;

alter function get_all_books(integer, integer) owner to postgres;

