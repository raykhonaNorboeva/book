create function get_all_books_active() returns integer
    language plpgsql
as
$$
declare
    active_count integer;
    begin
     select count(*) into active_count from books where is_active = true;
     return active_count;
    end;
    $$;

alter function get_all_books_active() owner to postgres;

