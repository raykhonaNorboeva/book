create function add_user(i_name character varying, i_username character varying, i_password character varying) returns integer
    language plpgsql
as
$$
begin
    if exists(select * from users where username = i_username) then
        return -1;
    else
        insert into users(name, username, password)
        VALUES (i_name, i_username, i_password);
        return 1;
    end if;
end;
$$;

alter function add_user(varchar, varchar, varchar) owner to postgres;

