create function get_books_by_category(page integer, i_title character varying, i_genre character varying, i_author character varying, lmt integer DEFAULT 2) returns SETOF books
    language plpgsql
as
$$
    declare
    title_db varchar;
    genre_db varchar;
    author_db varchar;
    begin

       if i_title is null then
           title_db = '';
           else title_db = i_title;
       end if;
       if i_genre is null then
           genre_db = '';
           else genre_db = i_genre;
       end if;
       if i_author is null then
           author_db = '';
           else author_db = i_author;
       end if;

       return query select * from books where title ilike '%' || title_db || '%' and genre ilike '%' || genre_db || '%'
                                and author ilike '%' || author_db || '%' 
                                and is_active = true limit lmt offset (page - 1) * lmt;
    end;
    $$;

alter function get_books_by_category(integer, varchar, varchar, varchar, integer) owner to postgres;

