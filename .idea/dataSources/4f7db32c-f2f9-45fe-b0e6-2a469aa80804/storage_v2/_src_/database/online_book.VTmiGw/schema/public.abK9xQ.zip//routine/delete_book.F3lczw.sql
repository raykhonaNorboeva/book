create function delete_book(i_book_id uuid) returns integer
    language plpgsql
as
$$
    begin
update books
        set is_active = false where id = i_book_id;
return 1;
    end;
    $$;

alter function delete_book(uuid) owner to postgres;

